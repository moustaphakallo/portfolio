import {
  Backpack,
  BadgeDollarSign,
  Bird,
  CalendarRange,
  ArrowUpRight,
} from "lucide-react";

// ─── Data ────────────────────────────────────────────────────────────────────

const stats = [
  {
    icon: <CalendarRange size={28} strokeWidth={1.5} />,
    value: "10.5K",
    label: "Active visitors",
  },
  {
    icon: <BadgeDollarSign size={28} strokeWidth={1.5} />,
    value: "33K",
    label: "Monthly product sales",
    highlight: true,
  },
  {
    icon: <Backpack size={28} strokeWidth={1.5} />,
    value: "45.5K",
    label: "Customers on our site",
  },
  {
    icon: <BadgeDollarSign size={28} strokeWidth={1.5} />,
    value: "25K",
    label: "Annual gross sales",
  },
];

const team = [
  {
    name: "Tom Cruise",
    role: "Founder & Chairman",
    img: "src/assets/images12.jpg",
  },
  {
    name: "Tom Cruise",
    role: "Founder & Chairman",
    img: "src/assets/sherwani-kurta-homme-sliman-haute-gamme-blanc.jpg",
  },
  {
    name: "Tom Cruise",
    role: "Founder & Chairman",
    img: "src/assets/costim1.jpg",
  },
];

// ─── Component ───────────────────────────────────────────────────────────────

export function Home() {
  return (
    <main className="home">

      {/* ── Our Story ── */}
      <section className="story">
        <div className="story__text">
          <span className="story__eyebrow">About us</span>
          <h1 className="story__title">Our Story</h1>
          <p>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Non
            recusandae officiis vitae temporibus cum quibusdam illum magnam,
            ipsam quaerat repellendus ullam ad et? Impedit aliquam repellendus
            rerum odio consequatur quod!
          </p>
          <p>
            Exceptional dolor sit amet consectetur adipisicing elit. Voluptatem
            ipsum adipisci eos tenetur maxime praesentium, quo assumenda quos at
            nulla incidunt corrupti vitae, nisi quas iure libero deleniti
            dolorem!
          </p>
        </div>
        <div className="story__image-wrap">
          <img src="src/assets/images12.jpg" alt="Notre histoire" />
        </div>
      </section>

      {/* ── Stats ── */}
      <section className="stats-section">
        <div className="stats-section__inner">
          <h2 className="section-title">Key Figures</h2>
          <div className="stats-grid">
            {stats.map((s, i) => (
              <div
                key={i}
                className={`stat-card${s.highlight ? " stat-card--accent" : ""}`}
              >
                <div className="stat-card__icon">{s.icon}</div>
                <strong className="stat-card__value">{s.value}</strong>
                <p className="stat-card__label">{s.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Team ── */}
      <section className="team-section">
        <div className="team-section__inner">
          <h2 className="section-title">Meet the Team</h2>
          <div className="team-grid">
            {team.map((member, i) => (
              <article key={i} className="team-card">
                <div className="team-card__image-wrap">
                  <img src={member.img} alt={member.name} />
                </div>
                <div className="team-card__body">
                  <h3 className="team-card__name">{member.name}</h3>
                  <p className="team-card__role">{member.role}</p>
                  <div className="team-card__socials">
                    <Bird size={16} strokeWidth={1.5} />
                    <ArrowUpRight size={16} strokeWidth={1.5} />
                    <span>LinkedIn</span>
                  </div>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      {/* ── Styles ── */}
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@400;600;700&family=Jost:wght@300;400;500&display=swap');

        :root {
          --cream: #f5f0e8;
          --ink: #1a1714;
          --stone: #7a736a;
          --accent: #c9a96e;
          --accent-dark: #a8854a;
          --white: #ffffff;
          --radius: 4px;
          --transition: 0.3s ease;
        }

        * { box-sizing: border-box; margin: 0; padding: 0; }

        .home {
          font-family: 'Jost', sans-serif;
          color: var(--ink);
          background: var(--cream);
        }

        /* ── Section title ── */
        .section-title {
          font-family: 'Cormorant Garamond', serif;
          font-size: clamp(28px, 4vw, 42px);
          font-weight: 600;
          text-align: center;
          letter-spacing: 0.02em;
          margin-bottom: 48px;
          color: var(--ink);
        }

        /* ── Story ── */
        .story {
          display: grid;
          grid-template-columns: 1fr 1fr;
          min-height: 520px;
          overflow: hidden;
        }

        .story__text {
          display: flex;
          flex-direction: column;
          justify-content: center;
          gap: 20px;
          padding: clamp(40px, 6vw, 96px);
          background: var(--white);
        }

        .story__eyebrow {
          font-size: 11px;
          font-weight: 500;
          letter-spacing: 0.2em;
          text-transform: uppercase;
          color: var(--accent-dark);
        }

        .story__title {
          font-family: 'Cormorant Garamond', serif;
          font-size: clamp(36px, 5vw, 64px);
          font-weight: 700;
          line-height: 1.05;
          letter-spacing: -0.01em;
        }

        .story__text p {
          font-size: 15px;
          line-height: 1.8;
          color: var(--stone);
          font-weight: 300;
        }

        .story__image-wrap {
          overflow: hidden;
        }

        .story__image-wrap img {
          width: 100%;
          height: 100%;
          object-fit: cover;
          transition: transform 0.6s ease;
        }

        .story__image-wrap:hover img {
          transform: scale(1.04);
        }

        /* ── Stats ── */
        .stats-section {
          padding: 80px 24px;
          background: var(--ink);
        }

        .stats-section__inner {
          max-width: 1100px;
          margin: 0 auto;
        }

        .stats-section .section-title {
          color: var(--white);
        }

        .stats-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
          gap: 20px;
        }

        .stat-card {
          background: rgba(255,255,255,0.05);
          border: 1px solid rgba(255,255,255,0.1);
          border-radius: var(--radius);
          padding: 32px 24px;
          text-align: center;
          transition: border-color var(--transition), transform var(--transition);
        }

        .stat-card:hover {
          border-color: var(--accent);
          transform: translateY(-4px);
        }

        .stat-card--accent {
          background: var(--accent);
          border-color: var(--accent);
        }

        .stat-card--accent .stat-card__value,
        .stat-card--accent .stat-card__label {
          color: var(--ink);
        }

        .stat-card--accent .stat-card__icon {
          color: var(--ink);
        }

        .stat-card__icon {
          color: var(--accent);
          margin-bottom: 16px;
          display: flex;
          justify-content: center;
        }

        .stat-card--accent .stat-card__icon {
          color: var(--ink);
        }

        .stat-card__value {
          display: block;
          font-family: 'Cormorant Garamond', serif;
          font-size: 48px;
          font-weight: 700;
          color: var(--white);
          line-height: 1;
          margin-bottom: 8px;
          letter-spacing: -0.02em;
        }

        .stat-card__label {
          font-size: 13px;
          color: rgba(255,255,255,0.55);
          font-weight: 300;
          letter-spacing: 0.04em;
        }

        /* ── Team ── */
        .team-section {
          padding: 80px 24px;
          background: var(--cream);
        }

        .team-section__inner {
          max-width: 1100px;
          margin: 0 auto;
        }

        .team-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
          gap: 28px;
        }

        .team-card {
          background: var(--white);
          border-radius: var(--radius);
          overflow: hidden;
          border: 1px solid rgba(0,0,0,0.07);
          transition: box-shadow var(--transition), transform var(--transition);
        }

        .team-card:hover {
          transform: translateY(-6px);
          box-shadow: 0 16px 40px rgba(0,0,0,0.1);
        }

        .team-card__image-wrap {
          overflow: hidden;
          height: 300px;
        }

        .team-card__image-wrap img {
          width: 100%;
          height: 100%;
          object-fit: cover;
          transition: transform 0.5s ease;
        }

        .team-card:hover .team-card__image-wrap img {
          transform: scale(1.05);
        }

        .team-card__body {
          padding: 24px;
        }

        .team-card__name {
          font-family: 'Cormorant Garamond', serif;
          font-size: 22px;
          font-weight: 600;
          margin-bottom: 4px;
        }

        .team-card__role {
          font-size: 13px;
          color: var(--stone);
          font-weight: 300;
          letter-spacing: 0.05em;
          text-transform: uppercase;
          margin-bottom: 16px;
        }

        .team-card__socials {
          display: flex;
          align-items: center;
          gap: 8px;
          font-size: 13px;
          color: var(--accent-dark);
          font-weight: 500;
          cursor: pointer;
          transition: color var(--transition);
        }

        .team-card__socials:hover {
          color: var(--ink);
        }

        /* ── Responsive ── */
        @media (max-width: 768px) {
          .story {
            grid-template-columns: 1fr;
          }

          .story__image-wrap {
            height: 280px;
          }

          .stats-section,
          .team-section {
            padding: 56px 16px;
          }

          .stat-card__value {
            font-size: 36px;
          }
        }
      `}</style>
    </main>
  );
}
